const DEMO_LLM_PROFILES = [
  {
    "id": "gpt",
    "name": "GPT",
    "family": "openai",
    "consistency": 91,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 92.29,
      "justice": 83.0,
      "truthfulness": 81.14,
      "courage": 76.29,
      "temperance": 82.29
    },
    "note": "Measured over 5 valid questionnaire runs."
  },
  {
    "id": "claude",
    "name": "Claude",
    "family": "anthropic",
    "consistency": 96,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 89.29,
      "justice": 83.1,
      "truthfulness": 85.95,
      "courage": 83.1,
      "temperance": 72.62
    },
    "note": "Measured over 3 valid questionnaire runs."
  },
  {
    "id": "gemini",
    "name": "Gemini",
    "family": "google",
    "consistency": 94,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 90.57,
      "justice": 78.86,
      "truthfulness": 82.86,
      "courage": 77.29,
      "temperance": 77.71
    },
    "note": "Measured over 5 valid questionnaire runs."
  },
  {
    "id": "llama",
    "name": "Llama",
    "family": "meta-llama",
    "consistency": 87,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 87.38,
      "justice": 80.36,
      "truthfulness": 83.1,
      "courage": 80.71,
      "temperance": 72.74
    },
    "note": "Measured over 6 valid questionnaire runs."
  },
  {
    "id": "deepseek",
    "name": "DeepSeek",
    "family": "deepseek",
    "consistency": 87,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 89.82,
      "justice": 74.11,
      "truthfulness": 78.75,
      "courage": 72.14,
      "temperance": 77.86
    },
    "note": "Measured over 4 valid questionnaire runs."
  },
  {
    "id": "mistral",
    "name": "Mistral",
    "family": "mistralai",
    "consistency": 86,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 91.19,
      "justice": 79.05,
      "truthfulness": 80.83,
      "courage": 75.6,
      "temperance": 78.21
    },
    "note": "Measured over 6 valid questionnaire runs."
  },
  {
    "id": "minimax",
    "name": "MiniMax",
    "family": "minimax",
    "consistency": 86,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 87.86,
      "justice": 83.81,
      "truthfulness": 85.36,
      "courage": 82.98,
      "temperance": 72.02
    },
    "note": "Measured over 6 valid questionnaire runs."
  },
  {
    "id": "grok",
    "name": "Grok",
    "family": "x-ai",
    "consistency": 94,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 91.79,
      "justice": 78.93,
      "truthfulness": 81.43,
      "courage": 76.79,
      "temperance": 78.39
    },
    "note": "Measured over 4 valid questionnaire runs."
  },
  {
    "id": "qwen",
    "name": "Qwen",
    "family": "qwen",
    "consistency": 91,
    "source": "measured-openrouter",
    "profile": {
      "wisdom": 93.43,
      "justice": 82.86,
      "truthfulness": 81.29,
      "courage": 76.86,
      "temperance": 80.43
    },
    "note": "Measured over 5 valid questionnaire runs."
  }
];
