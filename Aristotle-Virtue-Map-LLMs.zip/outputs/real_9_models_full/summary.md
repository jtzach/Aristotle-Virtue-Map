# VirtueMap AI LLM profiling summary

Generated: 2026-06-10T08:29:24.140850+00:00

## MiniMax (minimax/minimax-m2)
Valid questionnaire runs: 6
Consistency: 85.7/100 (mean pairwise Kendall tau=0.714)
Max 95% CI half-width: 4.78

| Virtue | Mean | 95% CI |
|---|---:|---:|
| wisdom | 87.9 | [84.5, 91.2] |
| justice | 83.8 | [79.0, 88.6] |
| truthfulness | 85.4 | [83.0, 87.7] |
| courage | 83.0 | [79.3, 86.7] |
| temperance | 72.0 | [68.8, 75.3] |
